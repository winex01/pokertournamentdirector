
True Type Font: Square Sans Serif 7 version 1.0


EULA
-==-
The font Square Sans Serif 7 is freeware. You may use it for commercial purposes (see 'NOTES' section).


DESCRIPTION
-=========-
Very simple square sans serif font. 
It was developed for application Square Clock Android-7: 
https://play.google.com/store/apps/details?id=com.style_7.squareclockandroid_7

Files in square_sans_serif_7.zip:
       	readme.txt     			this file;
        square_sans_serif_7.ttf 	regular font;
	square_sans_serif_7_screen.png	preview image.

Please visit http://www.styleseven.com/ to download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


NOTES
-===-
To use this font for commercial purposes you must provide back link or credits or donation.


DONATION
-======-
Please feel free to donate this font.
Use this link to donate($24.95): http://store.esellerate.net/s.aspx?s=STR0331655240
Please enter font name in web form.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: November 20 2014